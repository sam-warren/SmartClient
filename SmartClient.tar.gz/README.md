Sam Warren <br/>
V00889558 <br/>
CSC 361 Programming Assignment #1 <br/>
Spring 2021

### Running SmartClient
Run SmartClient with `python3 SmartClient.py www.example.com`
Replace www.example.com with the selected URL to check its properties.

### Missing Cookies
Some web servers may not exist at www.{HOST}.com, and may instead exist simply at {HOST}.com. If no cookies
are returned, try adding / removing the www. and one should return cookies.
